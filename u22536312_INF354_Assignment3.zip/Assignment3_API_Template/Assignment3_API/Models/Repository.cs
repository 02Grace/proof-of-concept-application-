﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3_API.Models
{
    // authentication model representing a user login record
    public class Authentication
    {
        public int Id { get; set; } // unique id
        public string Email { get; set; } // user's email
        public DateTime LoginTime { get; set; } // when the user logged in
    }

    public class Repository : IRepository
    {
        private readonly AppDbContext _appDbContext;

        // constructor to inject dbcontext
        public Repository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        // everthing is async in this repository and is based on the IRepository interface

        // add a generic entity to context (does not save)
        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        // save changes asynchronously, returns true if changes saved
        public async Task<bool> SaveChangesAsync()
        {
            return await _appDbContext.SaveChangesAsync() > 0;
        }

        // get all authentications asynchronously
        public async Task<Authentication[]> GetAllAuthenticationsAsync()
        {
            IQueryable<Authentication> query = _appDbContext.Authentications;
            return await query.ToArrayAsync();
        }

        // get all products with brand and product type included
        public async Task<Product[]> GetAllProductsAsync()
        {
            IQueryable<Product> query = _appDbContext.Products
                .Include(p => p.Brand)
                .Include(p => p.ProductType);
            return await query.ToArrayAsync();
        }

        // get all brands asynchronously
        public async Task<Brand[]> GetAllBrandsAsync()
        {
            IQueryable<Brand> query = _appDbContext.Brands;
            return await query.ToArrayAsync();
        }

        // get all product types asynchronously
        public async Task<ProductType[]> GetAllProductTypesAsync()
        {
            IQueryable<ProductType> query = _appDbContext.ProductTypes;
            return await query.ToArrayAsync();
        }

        // get a product type by id asynchronously
        public async Task<ProductType> GetProductTypeAsync(int productTypeId)
        {
            return await _appDbContext.ProductTypes.FindAsync(productTypeId);
        }

        // add a product asynchronously and save changes
        public async Task<Product> AddProductAsync(Product product)
        {
            _appDbContext.Products.Add(product);
            await _appDbContext.SaveChangesAsync();
            return product;
        }

        // delete product by id asynchronously and save changes
        public async Task<Product> DeleteProductAsync(int id)
        {
            var product = await _appDbContext.Products.FindAsync(id);
            if (product == null)
                return null;

            _appDbContext.Products.Remove(product);
            await _appDbContext.SaveChangesAsync();
            return product;
        }
    }
}
