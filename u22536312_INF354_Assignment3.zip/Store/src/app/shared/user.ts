export interface RegisterUser {
    emailaddress: string;
    password: string;
}
export interface User {
    token?: string
    user?: string
}