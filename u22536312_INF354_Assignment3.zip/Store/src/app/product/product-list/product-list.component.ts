// import needed modules and services
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ProductListingService } from '../../services/product-listing.service';
import { ProductListing } from '../../shared/product-listing';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.scss'
})
export class ProductListComponent implements OnInit {
  // table columns
  displayedColumns: string[] = ['image', 'name', 'price', 'brand', 'productTypeName', 'description'];
  dataSource = new MatTableDataSource<ProductListing>();
  errorMessage: string = '';

  // pagination setup
  pageSize = 5;
  pageSizeOptions = [5, 10, 25];
  currentPage = 0;
  totalItems = 0;

  // access paginator and sorting
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private productListingService: ProductListingService) {}

  // get products on load
  ngOnInit(): void {
    this.productListingService.GetProducts().subscribe(
      (products: any) => {
        this.dataSource.data = products;
      },
      (error: any) => {
        if (error.status === 401) {
          this.errorMessage = 'Unauthorized access. Please log in.';
        } else {
          this.errorMessage = 'An error occurred while fetching the products.';
        }
      }
    );
  }

  // setup table pagination and sort after view loads
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // filter table data
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
