// import required modules and services
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductListingService } from '../../services/product-listing.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Brands } from '../../shared/brand';
import { ProductTypes } from '../../shared/product-types';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit {
  // form and data variables
  productForm!: FormGroup;
  brandsData: Brands[] = [];
  productTypesData: ProductTypes[] = [];
  fileNameUploaded: string = '';
  formData: FormData = new FormData();

  constructor(
    private fb: FormBuilder,
    private productService: ProductListingService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  // initialize form and load dropdown data
  ngOnInit(): void {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      price: ['', Validators.required],
      brand: ['', Validators.required],
      producttype: ['', Validators.required],
      description: ['', Validators.required],
      image: ['', Validators.required]
    });

    this.getBrands();
    this.getProductTypes();
  }

  // load brands from api
  getBrands() {
    this.productService.getBrands().subscribe(
      (data) => (this.brandsData = data),
      (err) => console.error('error loading brands', err)
    );
  }

  // load product types from api
  getProductTypes() {
    this.productService.getProductTypes().subscribe(
      (data) => (this.productTypesData = data),
      (err) => console.error('error loading product types', err)
    );
  }

  // handle file upload
  uploadFile(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      this.formData.set('Image', file, file.name);
      this.productForm.patchValue({ image: file.name });
      this.fileNameUploaded = file.name;
    }
  }

  // submit form and send data to api
  onSubmit() {
    if (this.productForm.valid) {
      this.formData.set('Name', this.productForm.get('name')?.value);
      this.formData.set('Price', this.productForm.get('price')?.value);
      this.formData.set('Description', this.productForm.get('description')?.value);
      this.formData.set('Brand', this.productForm.get('brand')?.value);
      this.formData.set('ProductType', this.productForm.get('producttype')?.value);

      this.productService.addProduct(this.formData).subscribe(
        (res) => {
          this.snackBar.open(`${this.productForm.get('name')?.value} created successfully`, 'X', {
            duration: 5000
          });
          this.router.navigate(['/product']);
        },
        (err) => console.error('product creation failed:', err)
      );
    }
  }
}
