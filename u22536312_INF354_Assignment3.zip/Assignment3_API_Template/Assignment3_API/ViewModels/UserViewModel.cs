﻿namespace Assignment3_API.ViewModels
{
    public class UserViewModel
    {
        public string emailaddress { get; set; }
        public string password { get; set; }

    }
}
