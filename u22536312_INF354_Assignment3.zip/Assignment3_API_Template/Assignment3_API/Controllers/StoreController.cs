﻿using Assignment3_API.Models;
using Assignment3_API.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_API.Controllers
{
    // defining route and api controller attributes
    [Route("api/[controller]")]
    [ApiController]
    public class StoreController : ControllerBase
    {
        // injecting the repository to access data
        private readonly IRepository _repository;

        // constructor to initialize repository
        public StoreController(IRepository repository)
        {
            _repository = repository;
        }

        // endpoint to add a new product
        [HttpPost]
        [Route("addProducts")]
        public async Task<IActionResult> AddProducts([FromForm] AddProductViewModel productViewModel)
        {
            // convert uploaded image to base64 string if exists
            string base64Image = null;
            if (productViewModel.Image != null)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await productViewModel.Image.CopyToAsync(memoryStream);
                    var imageBytes = memoryStream.ToArray();
                    base64Image = Convert.ToBase64String(imageBytes);
                }
            }

            // create a product object with viewmodel data
            var products = new Product
            {
                Name = productViewModel.Name,
                Description = productViewModel.Description,
                Price = productViewModel.Price,
                Image = base64Image,
                BrandId = productViewModel.Brand,
                ProductTypeId = productViewModel.ProductType
            };

            // add product using repository and return result
            var addedProduct = await _repository.AddProductAsync(products);
            return Ok(addedProduct);
        }

        // endpoint to get all products as view models
        [HttpGet("ProductListing")]
        public async Task<IActionResult> ProductListing()
        {
            // get all products from repository
            var products = await _repository.GetAllProductsAsync();

            // convert to view models for frontend
            var productViewModels = products.Select(p => new ProductViewModel
            {
                price = p.Price,
                ProductTypeId = p.ProductTypeId,
                brandId = p.BrandId,
                description = p.Description,
                name = p.Name,
                image = p.Image,
                ProductTypeName = p.ProductType.Name,
                BrandName = p.Brand.Name
            }).ToArray();

            // return product list
            return Ok(productViewModels);
        }

        // endpoint to delete a product by id
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            // delete product using repository
            var deletedProduct = await _repository.DeleteProductAsync(id);
            if (deletedProduct == null)
            {
                return NotFound(); // return 404 if not found
            }

            return Ok(deletedProduct); // return deleted product
        }

        // endpoint to get all brands
        [HttpGet("GetBrands")]
        public async Task<IActionResult> GetBrands()
        {
            var brands = await _repository.GetAllBrandsAsync();
            return Ok(brands);
        }

        // endpoint to get all product types
        [HttpGet("GetProductTypes")]
        public async Task<IActionResult> GetProductTypes()
        {
            var productTypes = await _repository.GetAllProductTypesAsync();
            return Ok(productTypes);
        }
    }
}
