
import { Component, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chart, registerables } from 'chart.js';
import { ProductListingService } from '../../Services/product-listing.service';
import { RouterLink } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DataService } from '../../Services/data.service';

interface Product {
  productId: number;
  name: string;
  price: number;
  description: string;
  brandName: string;
  productTypeName: string;
  isActive: boolean;
}


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent implements  AfterViewInit {
  productsByBrand: any[] = [];
  productsByType: any[] = [];
  top10Products: Product[] = [];

  brandChartInstance!: Chart;
  productTypeChartInstance!: Chart;

  constructor(
    private dataService: ProductListingService, 
    private http: HttpClient,  
    private cdr: ChangeDetectorRef
  ) {
    Chart.register(...registerables);
  }

  ngAfterViewInit(): void {
    this.fetchData();
    this.fetchTop10Products();
  }

  fetchData() {
    this.dataService.getProductsByBrands().subscribe(data => {
      console.log('Products by Brands:', data);
      this.productsByBrand = data;
      this.createBrandChart();
    });
  
    this.dataService.getProductsByTypes().subscribe(data => {
      console.log('Products by Types:', data);
      this.productsByType = data;
      this.createProductTypeChart();
    });
  }
  
  createBrandChart() {
    const brandCtx = document.getElementById('brandChart') as HTMLCanvasElement;
    new Chart(brandCtx, {
      type: 'pie',
      data: {
        labels: this.productsByBrand.map(item => item.brand), 
        datasets: [{
          label: 'Products by Brand',
          data: this.productsByBrand.map(item => item.count),
          backgroundColor: [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', 
            '#FF9F40', '#8AC926', '#1982C4', '#6A4C93', '#FF595E'
          ],
          hoverOffset: 4
        }]
      },
      options: {
        responsive: false, // You can make it false to remove the responsiveness of the chart
        plugins: {
          legend: {
            position: 'right',
          },
          title: {
            display: true, 
            text: 'Product Count by Brand'
          }
        }
      }
    });
  }
  
  createProductTypeChart() {
    const productTypeCtx = document.getElementById('productTypeChart') as HTMLCanvasElement;
    new Chart(productTypeCtx, {
      type: 'pie',
      data: {
        labels: this.productsByType.map(item => item.productType), 
        datasets: [{
          label: 'Products by Type',
          data: this.productsByType.map(item => item.count),
          backgroundColor: [
            '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', 
            '#FF9F40', '#8AC926', '#1982C4', '#6A4C93', '#FF595E', '#FF6384'
          ],
          hoverOffset: 4
        }]
      },
      options: {
        responsive: false,  // You can make it false to remove the responsiveness of the chart
        plugins: {
          legend: {
            position: 'right',
          },
          title: {
            display: true,  
            text: 'Product Count by Type'
          }
        }
      }
    });
  }

  fetchTop10Products() {
    this.dataService.GetProducts().subscribe(products => {
      // Sort products by price in descending order and take top 10
      this.top10Products = products
        .sort((a: Product, b: Product) => b.price - a.price)
        .slice(0, 10);
      
      console.log('Top 10 Products:', this.top10Products);
    });
  }
}