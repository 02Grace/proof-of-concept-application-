﻿using Assignment3_API.Models;
using Assignment3_API.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace YourAppNamespace.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        // tools we need for user management, config, logging, and data
        private readonly UserManager<AppUser> _userManager;
        private readonly IRepository _repository;
        private readonly IUserClaimsPrincipalFactory<AppUser> _claimsPrincipalFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AuthenticationController> _logger;

        // constructor to get the tools from dependency injection
        public AuthenticationController(
            UserManager<AppUser> userManager,
            IUserClaimsPrincipalFactory<AppUser> claimsPrincipalFactory,
            IConfiguration configuration,
            IRepository repository,
            ILogger<AuthenticationController> logger)
        {
            _userManager = userManager;
            _claimsPrincipalFactory = claimsPrincipalFactory;
            _configuration = configuration;
            _repository = repository;
            _logger = logger;
        }

        // get all authentication records from the database
        [HttpGet]
        [Route("GetAllAuthentication")]
        public async Task<IActionResult> GetAllAuthenticationAsync()
        {
            try
            {
                // get all authentication data from the repository
                var results = await _repository.GetAllAuthenticationsAsync();
                return Ok(results); // send back data with 200 OK
            }
            catch (Exception ex)
            {
                // log error and send 500 internal server error
                _logger.LogError(ex, "error in GetAllAuthenticationAsync");
                return StatusCode(StatusCodes.Status500InternalServerError, "internal server error, please contact support");
            }
        }

        // register a new user with email and password
        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register([FromBody] UserViewModel uvm)
        {
            // check if input is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(new { success = false, message = "invalid input data" });
            }

            try
            {
                // look for user by email to check if exists
                var user = await _userManager.FindByEmailAsync(uvm.emailaddress);

                if (user == null)
                {
                    // create new user object
                    user = new AppUser
                    {
                        Id = Guid.NewGuid().ToString(),
                        UserName = uvm.emailaddress,
                        Email = uvm.emailaddress
                    };

                    // try to save user with password
                    var result = await _userManager.CreateAsync(user, uvm.password);

                    if (result.Succeeded)
                    {
                        return Ok(new { success = true }); // registration successful
                    }
                    else
                    {
                        // show errors if creating user failed
                        return BadRequest(new { success = false, errors = result.Errors });
                    }
                }
                else
                {
                    // user already exists, return conflict
                    return Conflict(new { success = false, message = "user already exists" });
                }
            }
            catch (Exception ex)
            {
                // log error and send server error response
                _logger.LogError(ex, "error during registration");
                return StatusCode(StatusCodes.Status500InternalServerError, "internal server error, please contact support");
            }
        }

        // user login with email and password
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromBody] UserViewModel uvm)
        {
            // check if input data is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(new { success = false, message = "invalid input data" });
            }

            try
            {
                _logger.LogInformation($"attempting login for {uvm.emailaddress}");

                // find user by email
                var user = await _userManager.FindByEmailAsync(uvm.emailaddress);

                // check if user exists and password is correct
                if (user != null && await _userManager.CheckPasswordAsync(user, uvm.password))
                {
                    _logger.LogInformation($"login successful for {uvm.emailaddress}");
                    // create and return jwt token
                    return GenerateJWTToken(user);
                }
                else
                {
                    _logger.LogWarning($"login failed for {uvm.emailaddress} - invalid credentials");
                    // user not found or wrong password
                    return NotFound(new { success = false, message = "user not found or invalid credentials" });
                }
            }
            catch (Exception ex)
            {
                // log error and return 500 server error
                _logger.LogError(ex, "error during login");
                return StatusCode(StatusCodes.Status500InternalServerError, $"internal server error: {ex.Message}");
            }
        }

        // create a jwt token for the logged in user
        private ActionResult GenerateJWTToken(AppUser user)
        {
            // claims to put inside token
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName)
            };

            // get secret key from appsettings
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Tokens:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            // make the token, set issuer, audience, claims, expiry, and sign it
            var token = new JwtSecurityToken(
                _configuration["Tokens:Issuer"],
                _configuration["Tokens:Audience"],
                claims,
                expires: DateTime.UtcNow.AddHours(3),
                signingCredentials: credentials
            );

            // send token back to client
            return Ok(new
            {
                success = true,
                token = new JwtSecurityTokenHandler().WriteToken(token),
                user = user.UserName
            });
        }
    }
}
