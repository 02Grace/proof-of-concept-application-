// import modules and services
import { Component, AfterViewInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { ProductListingService } from '../../services/product-listing.service';

// define product interface
interface Product {
  productId: number;
  name: string;
  price: number;
  description: string;
  brandName: string;
  productTypeName: string;
  isActive: boolean;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit {
  // store chart data
  productsByBrand: { brand: string; count: number }[] = [];
  productsByType: { productType: string; count: number }[] = [];
  top10Products: Product[] = [];

  brandChartInstance!: Chart;
  productTypeChartInstance!: Chart;

  constructor(private dataService: ProductListingService) {
    Chart.register(...registerables);
  }

  // load charts and top 10 data after view is ready
  ngAfterViewInit(): void {
    this.fetchData();
    this.fetchTop10Products();
  }

  // get data for brand and type charts
  fetchData() {
    this.dataService.getProductsByBrands().subscribe(data => {
      this.productsByBrand = data;
      this.createBrandChart();
    });

    this.dataService.getProductsByTypes().subscribe(data => {
      this.productsByType = data;
      this.createProductTypeChart();
    });
  }

  // create brand pie chart
  createBrandChart() {
    const brandCtx = document.getElementById('brandChart') as HTMLCanvasElement;
    if (this.brandChartInstance) this.brandChartInstance.destroy();

    this.brandChartInstance = new Chart(brandCtx, {
      type: 'pie',
      data: {
        labels: this.productsByBrand.map(item => item.brand),
        datasets: [{
          label: 'Products by Brand',
          data: this.productsByBrand.map(item => item.count),
          backgroundColor: [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
            '#FF9F40', '#8AC926', '#1982C4', '#6A4C93', '#FF595E'
          ],
          hoverOffset: 4
        }]
      },
      options: {
        responsive: false,
        plugins: {
          legend: { position: 'right' },
          title: { display: true, text: 'Product Count by Brand' }
        }
      }
    });
  }

  // create product type pie chart
  createProductTypeChart() {
    const productTypeCtx = document.getElementById('productTypeChart') as HTMLCanvasElement;
    if (this.productTypeChartInstance) this.productTypeChartInstance.destroy();

    this.productTypeChartInstance = new Chart(productTypeCtx, {
      type: 'pie',
      data: {
        labels: this.productsByType.map(item => item.productType),
        datasets: [{
          label: 'Products by Type',
          data: this.productsByType.map(item => item.count),
          backgroundColor: [
            '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
            '#FF9F40', '#8AC926', '#1982C4', '#6A4C93', '#FF595E', '#FF6384'
          ],
          hoverOffset: 4
        }]
      },
      options: {
        responsive: false,
        plugins: {
          legend: { position: 'right' },
          title: { display: true, text: 'Product Count by Type' }
        }
      }
    });
  }

  // get top 10 products by price
  fetchTop10Products() {
    this.dataService.GetProducts().subscribe(products => {
      this.top10Products = products
        .sort((a: Product, b: Product) => b.price - a.price)
        .slice(0, 10);
    });
  }
}
