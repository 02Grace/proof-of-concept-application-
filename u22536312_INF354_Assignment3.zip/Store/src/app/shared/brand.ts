export interface Brands {
    brandId: number;
    name: string;
}
