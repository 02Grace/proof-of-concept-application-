﻿using Assignment3_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Assignment3_API.Controllers
{
    // setting the route prefix for the controller
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        // injecting the database context
        private readonly AppDbContext _context;

        // constructor to initialize the context
        public ReportController(AppDbContext context)
        {
            _context = context;
        }

        // endpoint to get total number of products grouped by brand
        [HttpGet("products-by-brands")]
        public async Task<IActionResult> GetProductsByBrands()
        {
            // getting all active products with their brand info
            var products = await _context.Products
                .Include(p => p.Brand)
                .Where(p => p.IsActive)
                .ToListAsync();

            // grouping products by brand name and counting each group
            var result = products.GroupBy(p => p.Brand.Name)
                                 .Select(g => new { Brand = g.Key, Count = g.Count() })
                                 .ToList();

            // returning the result
            return Ok(result);
        }

        // endpoint to get total number of products grouped by type
        [HttpGet("products-by-types")]
        public async Task<IActionResult> GetProductsByTypes()
        {
            // getting all active products with their type info
            var products = await _context.Products
                .Include(p => p.ProductType)
                .Where(p => p.IsActive)
                .ToListAsync();

            // grouping products by type name and counting each group
            var result = products.GroupBy(p => p.ProductType.Name)
                                 .Select(g => new { ProductType = g.Key, Count = g.Count() })
                                 .ToList();

            // returning the result
            return Ok(result);
        }

        // endpoint to get the top 10 most expensive active products
        [HttpGet("top-10-expensive")]
        public async Task<IActionResult> GetTop10ExpensiveProducts()
        {
            // getting top 10 active products by price, including brand and type details
            var products = await _context.Products
                .Where(p => p.IsActive)
                .Include(p => p.Brand)
                .Include(p => p.ProductType)
                .OrderByDescending(p => p.Price)
                .Take(10)
                .Select(p => new
                {
                    p.ProductId,
                    p.Name,
                    p.Price,
                    p.Description,
                    BrandName = p.Brand.Name,
                    ProductTypeName = p.ProductType.Name
                })
                .ToListAsync();

            // returning the list of top 10 expensive products
            return Ok(products);
        }
    }
}
