﻿namespace Assignment3_API.Models
{
   
    public interface IRepository
    {
        // save all changes asynchronously and returns true if successful
        Task<bool> SaveChangesAsync();

        // adding a generic entity to the context (* note this is not saved)
        void Add<T>(T entity) where T : class;

        // geting all authentication records asynchronously
        Task<Authentication[]> GetAllAuthenticationsAsync();

        // retreiving  all products asynchronously
        Task<Product[]> GetAllProductsAsync();

        // getting all brands asynchronously
        Task<Brand[]> GetAllBrandsAsync();

        // getting all product types asynchronously
        Task<ProductType[]> GetAllProductTypesAsync();

        // getting a product type by its id asynchronously
        Task<ProductType> GetProductTypeAsync(int productTypeId);

        // addition of a product asynchronously and return it (* not this saves changes)
        Task<Product> AddProductAsync(Product product);

        // deletion of a product by id asynchronously and return deleted product
        Task<Product> DeleteProductAsync(int id);
    }
}
