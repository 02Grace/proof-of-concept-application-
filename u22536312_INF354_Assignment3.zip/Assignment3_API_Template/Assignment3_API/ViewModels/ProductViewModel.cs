﻿namespace Assignment3_API.ViewModels
{
    public class ProductViewModel
    {
        public decimal price { get; set; }
        public int ProductTypeId { get; set; }
        public string ProductTypeName { get; set; }
        public int brandId { get; set; }
        public string BrandName { get; set; }
        public string description { get; set; }
        public string name { get; set; }
        public string? image { get; set; }


    }
}
