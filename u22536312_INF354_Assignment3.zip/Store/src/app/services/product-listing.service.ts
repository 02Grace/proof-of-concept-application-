import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductListingService {

  // base api url
  apiUrl = 'https://localhost:7121/api/';

  // http headers
  httpOptions = {
    headers: new HttpHeaders({
      ContentType: 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) {}

  // get all products
  GetProducts(): Observable<any> {
    return this.httpClient.get<any>(`${this.apiUrl}Store/ProductListing`)
      .pipe(map(result => result));
  }

  // sort products by given field and order
  sortProductsByField(field: string, order: string): Observable<any> {
    const url = `${this.apiUrl}?sort=${field}&order=${order}`;
    return this.httpClient.get<any>(url);
  }

  // filter products by keyword
  filterProductsByKeyword(keyword: string): Observable<any> {
    const url = `${this.apiUrl}?filter=${keyword}`;
    return this.httpClient.get<any>(url);
  }

  // add new product
  addProduct(product: FormData): Observable<any> {
    return this.httpClient.post<any>(`${this.apiUrl}Store/addProducts`, product);
  }

  // get all brands
  getBrands(): Observable<any> {
    return this.httpClient.get<any>(`${this.apiUrl}Store/GetBrands`);
  }

  // get all product types
  getProductTypes(): Observable<any> {
    return this.httpClient.get<any>(`${this.apiUrl}Store/GetProductTypes`);
  }

  // get product count grouped by brand
  getProductsByBrands(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.apiUrl}Report/products-by-brands`);
  }

  // get product count grouped by type
  getProductsByTypes(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.apiUrl}Report/products-by-types`);
  }

  // get product type details
  getproductTypes(): Observable<ProductType[]> {
    return this.httpClient.get<ProductType[]>(`${this.apiUrl}/GetProductTypes`);
  }

  // get only active products
  getActiveProducts(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.apiUrl}Report/GetActiveProducts`);
  }
}

// product interface
export interface Product {
  productId: number;
  name: string;
  description: string;
  price: number;
  isActive: boolean;
}

// product type interface
export interface ProductType {
  productTypeId: number;
  name: string;
  description: string;
  products: Product[];
}
